#!/usr/bin/env bash

set -ex

usermod vcap -a -G vagrant
