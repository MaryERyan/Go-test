#!/bin/bash

set -ex

apt-get -y update
apt-get -y clean
